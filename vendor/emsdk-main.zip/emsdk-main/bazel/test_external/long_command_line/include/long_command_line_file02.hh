#pragma once

void f2();

#pragma once

void f6();

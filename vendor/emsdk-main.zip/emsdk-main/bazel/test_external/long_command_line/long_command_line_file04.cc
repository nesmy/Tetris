#include "long_command_line_file04.hh"

#include <iostream>

void f4() { std::cout << "hello from f4()\n"; }

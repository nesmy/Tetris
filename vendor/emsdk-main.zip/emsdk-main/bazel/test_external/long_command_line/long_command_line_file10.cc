#include "long_command_line_file10.hh"

#include <iostream>

void f10() { std::cout << "hello from f10()\n"; }
